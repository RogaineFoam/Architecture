Our project can be run how you requested, via "$ python team4_project1.py -i test1_bin.txt -o team4_out"

Team Members (name, netID): 
Sam Pugh, sap163
William Fallin, waf13
