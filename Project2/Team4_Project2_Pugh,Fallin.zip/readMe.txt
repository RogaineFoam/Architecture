Participants:
  William Fallin, Samuel Pugh

Date Submitted:
  11/01/2018

How to Run:
  python team4_project2.py -i test2_bin.txt -o team4_out
